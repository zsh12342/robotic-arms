import json
import numpy as np
import transforms3d as t3d
import math
from tongverselite.tcp import PersistentTcpClient, json2bin
from tongverselite.solver import TaskSolverBase

def orientation(goal1,goal2,pos1,pos2,rpy2):
    dx = goal1 - pos1
    dy = goal2 - pos2
    target_dir = np.arctan2(dy, dx)
    diff_rot = target_dir - rpy2

    return diff_rot,dx,dy


class BipedWalkingCtrlClient(PersistentTcpClient):
    def send_request(self, msg):
        data_bin = json2bin(msg)
        return json.loads(self.send(data_bin).decode("ascii"))

    def get_cmd(self, obs, vx, vy, theta, state):
        obs_agent = obs["agent"]
        q_leg = obs_agent["joint_state"]["legs_positions"]
        dq_leg = obs_agent["joint_state"]["legs_velocities"]

        q_arm = obs_agent["joint_state"]["arms_positions"]
        dq_arm = obs_agent["joint_state"]["arms_velocities"]

        p_wb = obs_agent["body_state"]["world_pos"]
        quat_wb = obs_agent["body_state"]["world_orient"]
        v_wb = obs_agent["body_state"]["linear_velocities"]
        w_wb = obs_agent["body_state"]["angular_velocities"]
      

        msg = {
            "q_leg": q_leg.tolist(),
            "dq_leg": dq_leg.tolist(),
            "q_arm": q_arm.tolist(),
            "dq_arm": dq_arm.tolist(),
            "p_wb": p_wb.tolist(),
            "quat_wb": quat_wb.tolist(),
            "v_wb": v_wb.tolist(),
            "w_wb": w_wb.tolist(),
            "command": [vx, vy, theta],
            "change_state": state,
            
        }
        joint_efforts = self.send_request(msg)

        return joint_efforts


class TaskSolver(TaskSolverBase):
    def __init__(self) -> None:
        super().__init__()
        self.ctrl_client_ = BipedWalkingCtrlClient(ip="0.0.0.0", port=8800)
        self.goal1 = np.array([0.2, -2.38535, 0.26098])
        self.goal2 = np.array([0.19856, -1.5914, 0.30632])
        self.goal3 = np.array([0.23457, -1.44135, 0.593])
        self.step = 0
        self.count = 0
    def next_action(self, obs: dict) -> dict:
        agent = obs["agent"]
        pos = agent["body_state"]["world_pos"]
        quat = agent["body_state"]["world_orient"]
        q_arm = agent["joint_state"]["arms_positions"]
       
        # q_leg = agent["joint_state"]["legs_positions"]
        # dq_leg = agent["joint_state"]["legs_velocities"]
        rpy = t3d.euler.quat2euler(quat, axes="sxyz")
        diff_rot,dx,dy = orientation(self.goal3[0],self.goal3[1],pos[0],pos[1],rpy[2])
        distaction = math.sqrt(dx*dx+dy*dy)
        print(self.step)
        print(distaction)
        target_dir = np.arctan2(dy, dx)
        # diff_rot1 = orientation(self.goal1[0],self.goal1[1],pos[0],pos[1],rpy[2])
        # diff_rot2 = orientation(self.goal2[0],self.goal2[1],pos[0],pos[1],rpy[2])
        #diff_rot3 = orientation(self.goal3[0],self.goal3[1],pos[0],pos[1],rpy[2])
        diff_rot = target_dir - rpy[2]
        # print(f"legs_velocities:{dq_leg}")
        if self.step == 0:
            joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.15, 0, 0, False
                )
            self.count+=1
            if self.count == 3500:
                self.step+=1
                print(self.step)

            # wrap joint effort into tongverse-lite action format
            action = {
               "legs": {
                    "ctrl_mode": joint_efforts["mode"],
                   "joint_values": joint_efforts["effort"],
                    "stiffness": [],
                    "dampings": [],
                }
            }

            return action
        if self.step == 1:
         if distaction <= 0.3:
            self.step+=1
            print(self.step)
            joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.05, -0.1, 0.0, False
                )
         else:      
            if abs(diff_rot) > np.pi:
                diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

            if abs(diff_rot) < np.pi / 90:
                
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.25, 0.1, 0.0, False
                )
                # if distaction <= 0.3:
                #     self.step+=1
                #     print(self.step)
                #     joint_efforts = self.ctrl_client_.get_cmd(
                #     obs, 0.05, -0.1, 0.2, False
                # )
            elif diff_rot > 0:
                
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.2, 0.1, 0.0, False
                )
            else:
                
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.2, -0.1, -0.0, False
                )

            # wrap joint effort into tongverse-lite action format
            action = {
                "legs": {
                    "ctrl_mode": joint_efforts["mode"],
                    "joint_values": joint_efforts["effort"],
                    "stiffness": [],
                    "dampings": [],
                }
            }

            return action
        if self.step==2 :
            print("准备按了")
            #右手
            q_arm[7] = 1.7
            q_arm[4] = -1.7
            q_arm[6]=1.7
            #左手
            #q_arm[3] = 1.7
            #q_arm[0] = -1.7
            q_arm[2]=1.7
            joint_efforts = self.ctrl_client_.get_cmd(
            obs, 0.2 , 0.0, -0.0, False
            )
            action = {
                "legs": {
                    "ctrl_mode": joint_efforts["mode"],
                    "joint_values": joint_efforts["effort"],
                    "stiffness": [],
                    "dampings": [],
                },
                "arms":{
                    "ctrl_mode":"position",
                    "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                    "stiffness":[],
                    "dampings":[],
                },
               
            
            }

            return action
        
