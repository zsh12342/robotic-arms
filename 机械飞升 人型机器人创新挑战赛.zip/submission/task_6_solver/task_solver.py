import json
import numpy as np
import transforms3d as t3d
import math
from tongverselite.tcp import PersistentTcpClient, json2bin
from tongverselite.solver import TaskSolverBase

def orientation(goal1,goal2,pos1,pos2,rpy2):
    dx = goal1 - pos1
    dy = goal2 - pos2
    target_dir = np.arctan2(dy, dx)
    diff_rot = target_dir - rpy2

    return diff_rot,dx,dy

class BipedWalkingCtrlClient(PersistentTcpClient):
    def send_request(self, msg):
        data_bin = json2bin(msg)
        return json.loads(self.send(data_bin).decode("ascii"))

    def get_cmd(self, obs, vx, vy, theta, state):
        obs_agent = obs["agent"]
        q_leg = obs_agent["joint_state"]["legs_positions"]
        dq_leg = obs_agent["joint_state"]["legs_velocities"]

        q_arm = obs_agent["joint_state"]["arms_positions"]
        dq_arm = obs_agent["joint_state"]["arms_velocities"]

        p_wb = obs_agent["body_state"]["world_pos"]
        quat_wb = obs_agent["body_state"]["world_orient"]
        v_wb = obs_agent["body_state"]["linear_velocities"]
        w_wb = obs_agent["body_state"]["angular_velocities"]
        pick = obs["pick"]
        str_goal = obs["goal"]
        # cam1 = obs["cam1"]["rgb"]
        # ds = obs["cam1"]["distance_to_image_plane"]
        msg = {
            "q_leg": q_leg.tolist(),
            "dq_leg": dq_leg.tolist(),
            "q_arm": q_arm.tolist(),
            "dq_arm": dq_arm.tolist(),
            "p_wb": p_wb.tolist(),
            "quat_wb": quat_wb.tolist(),
            "v_wb": v_wb.tolist(),
            "w_wb": w_wb.tolist(),
            # "cam1":cam1.tolist(),
            # "distance_to_image_planes":ds.tolist(),
            "command": [vx, vy, theta],
            "change_state": state,
            "pick":pick,
            "goal":str_goal,

        }
        joint_efforts = self.send_request(msg)

        return joint_efforts


class TaskSolver(TaskSolverBase):
    def __init__(self) -> None:
        super().__init__()

        # create a controller client that request joint effort commands from the server
        # note that ip MUST be "0.0.0.0" and port MUST be 8800
        self.ctrl_client_ = BipedWalkingCtrlClient(ip="0.0.0.0", port=8800)
        
        # the goal position as given in the task specification
        self.goal_coffee_mug= np.array([-2.38805, 1.20448, 1.29284])
        self.goal_coffeetable = np.array([-0.31258,4.8777,1.04843])
        self.goal_toy1=np.array([-0.31258,3.8777,1.04843])
        self.goal_toy2=np.array([-4.10655,4.5883,1.21815])
        self.goal_toy3=np.array([-1.20391,3.82876,1.34963])
        self.goal_red1=np.array([-1.20391,3.82876,1.34963])
        self.goal_red2=np.array([-1.20391,6.44205,1.34963])
        self.goal_red3=np.array([0.12871,6.44205,1.34963])
        self.goal_red4=np.array([0.12871,9.52085,1.34963])
        self.goal_red5=np.array([4.45252,9.52085,1.34963])
        self.goal_red6=np.array([0.12871,6.44205,1.34963])
        self.step = 0
    def next_action(self, obs: dict) -> dict:
        agent = obs["agent"]
        pos = agent["body_state"]["world_pos"]
        quat = agent["body_state"]["world_orient"]
        q_arm = agent["joint_state"]["arms_positions"]
        # cam1 = obs["cam"]["rgb"]
        # ds = obs["cam"]["distance_to_image_plane"]
        #print(obs)
        
        str_goal = obs["goal"]
        # print(str_goal)
        pick = obs["pick"]
        rpy = t3d.euler.quat2euler(quat, axes="sxyz")
        if "coffee_mug" in str_goal:
            if self.step == 0:
                    # calculate the difference between the target direction and the current direction
                    diff_rot,dx,dy = orientation(self.goal_coffee_mug[0],self.goal_coffee_mug[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print(str_goal)
                    print("寻物")
                    # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                    if abs(diff_rot) < np.pi / 90 and distaction<=0.8:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.0, 0, 0, False
                        )
                        self.step+=1
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.0, 0, 0, False
                        )
                    elif abs(diff_rot) < np.pi / 90 and distaction>0.8 :
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.3, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.05, 0.2, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.05, -0.2, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                    }

                    return action
            if self.step == 1:
                    # diff_rot,dx,dy = orientation(self.goal_coffee_mug[0],self.goal_coffee_mug[1],pos[0],pos[1],rpy[2])
                    # distaction = math.sqrt(dx*dx+dy*dy)
                    # joint_efforts = self.ctrl_client_.get_cmd(
                    #     obs, 0.0, 0, 0, False
                    # )
                    print('取物品')
                    if not pick:
                        q_arm[7] = 1.8
                        q_arm[6] =1.8
                        q_arm[4] = -1.5
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.1, 0.1, 0, False
                        )
                    else:
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.3, 1
                        )
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.3, 1
                        )
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.3, 1
                        )
                        self.step+=1
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                        # "release":'False'
                    }
                    return action
            if self.step == 2:
                    diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print('前往目的地')
                    q_arm[7] = 1.8
                    q_arm[6] =1.8
                    q_arm[4] = -1.8
                    # joint_efforts = self.ctrl_client_.get_cmd(
                    #     obs, 0.3, 0, 0, False
                    # )
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    if abs(diff_rot) < np.pi / 90 and distaction<=1.0:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.0, 0, 0, False
                        )
                        self.step+=1
                    elif abs(diff_rot) < np.pi / 90 and distaction>1.0:
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.3, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.05, 0.2, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.05, -0.2, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand',
                        "release":'False'
                    }

                    return action
                
            if self.step == 3:
                    # diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                    # distaction = math.sqrt(dx*dx+dy*dy)
                    print('放物品')
                    joint_efforts = self.ctrl_client_.get_cmd(
                        obs, 0.0, 0, 0, 0
                    )
                    q_arm[7] = -1.0

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":None,
                            "dampings":[],
                        },
                        #"pick":'right_hand',
                        "release":True
                    }

                    return action
        ##if "coffee_mug" in str_goal:
        #首先根据坐标找东西 step1
        #然后到位置之后拿东西 step2
        #然后拿到东西之后在if找地点 设计路线 在哪里转弯（设计一个点）step3
        #到地方之后放东西 step4
        if "teddy" in str_goal:
            if self.step == 0:
                    # calculate the difference between the target direction and the current direction
                    diff_rot,dx,dy = orientation(self.goal_toy1[0],self.goal_toy1[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print(str_goal)
                    print("找目标点一")
                    # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                    if abs(diff_rot) < np.pi / 90 and distaction<=0.9:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.65, 0, 0, False
                        )
                        self.step+=1
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.65, 0, 0, False
                        )
                    elif abs(diff_rot) < np.pi / 90 and distaction>0.9:
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.5, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.15, 0.65, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.15, -0.65, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                    }

                    return action
            if self.step == 1:
                    # calculate the difference between the target direction and the current direction
                    diff_rot,dx,dy = orientation(self.goal_toy2[0],self.goal_toy2[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print(str_goal)
                    print("寻物")
                    # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                    if abs(diff_rot) < np.pi / 90 and distaction<=0.9:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.7, 0, 0, False
                        )
                        self.step+=1
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.7, 0, 0, False
                        )
                    elif abs(diff_rot) < np.pi / 90 and distaction>0.9 :
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.3, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.03, 0.5, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.03, -0.5, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                    }

                    return action
            if self.step == 2:
                    # diff_rot,dx,dy = orientation(self.goal_coffee_mug[0],self.goal_coffee_mug[1],pos[0],pos[1],rpy[2])
                    # distaction = math.sqrt(dx*dx+dy*dy)
                    # joint_efforts = self.ctrl_client_.get_cmd(
                    #     obs, 0.0, 0, 0, False
                    # )
                    print('取物品')
                    if not pick:
                        q_arm[7] = 1.8
                        q_arm[6] =1.8
                        q_arm[4] = -1.5
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.1, 0.1, 0, False
                        )
                    else:
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.6, 1
                        )
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.6, 1
                        )
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, -2.0, 0.2, -0.6, 1
                        )
                        self.step+=1
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                        # "release":'False'
                    }
                    return action
            if self.step == 3:
                    # calculate the difference between the target direction and the current direction
                    diff_rot,dx,dy = orientation(self.goal_toy3[0],self.goal_toy3[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print(str_goal)
                    print("找目标点一")
                    q_arm[7] = 1.8
                    q_arm[6] =1.8
                    q_arm[4] = -1.5
                    # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                    if abs(diff_rot) < np.pi / 90 and distaction<=0.6:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.25, 0, 0, False
                        )
                        self.step+=1
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.25, 0, 0, False
                        )
                    elif abs(diff_rot) < np.pi / 90 and distaction>0.6 :
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.15, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.0, 0.55, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.0, -0.55, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand'
                    }

                    return action
            if self.step == 4:
                    diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                    distaction = math.sqrt(dx*dx+dy*dy)
                    print('前往目的地')
                    q_arm[7] = 1.8
                    q_arm[6] =1.8
                    q_arm[4] = -1.8
                    # joint_efforts = self.ctrl_client_.get_cmd(
                    #     obs, 0.3, 0, 0, False
                    # )
                    if abs(diff_rot) > np.pi:
                        diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                    if abs(diff_rot) < np.pi / 90 and distaction<=1.0:
                        # call bipedal controller to get joint effort given a target velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.02, 0, 0, False
                        )
                        self.step+=1
                    elif abs(diff_rot) < np.pi / 90 and distaction>1.0:
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.6, 0, 0, False
                        )
                    elif diff_rot > 0:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, 0.05, 0.65, False
                        )
                    else:
                        # call bipedal controller to get joint effort given a target angular velocity
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0, -0.05, -0.65, False
                        )

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":[],
                            "dampings":[],
                        },
                        "pick":'right_hand',
                        "release":'False'
                    }

                    return action
                
            if self.step == 5:
                    # diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                    # distaction = math.sqrt(dx*dx+dy*dy)
                    print('放物品')
                    joint_efforts = self.ctrl_client_.get_cmd(
                        obs, 0.0, 0, 0, 0
                    )
                    q_arm[7] = -1.0

                    # wrap joint effort into tongverse-lite action format
                    action = {
                        "legs": {
                            "ctrl_mode": joint_efforts["mode"],
                            "joint_values": joint_efforts["effort"],
                            "stiffness": [],
                            "dampings": [],
                        },
                        "arms":{
                            "ctrl_mode":"position",
                            "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                            "stiffness":None,
                            "dampings":[],
                        },
                        #"pick":'right_hand',
                        "release":True
                    }

                    return action
            if "red" in str_goal:
                if self.step == 0:
                        # calculate the difference between the target direction and the current direction
                        diff_rot,dx,dy = orientation(self.goal_red1[0],self.goal_red1[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("找目标点一")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.7:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.7:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.10, 0.65, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.10, -0.65, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 1:
                        # calculate the difference between the target direction and the current direction
                        diff_rot,dx,dy = orientation(self.goal_red2[0],self.goal_red2[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("找目标点二")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.7:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.7:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.10, 0.65, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.10, -0.65, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 2:
                        # calculate the difference between the target direction and the current direction
                        diff_rot,dx,dy = orientation(self.goal_red3[0],self.goal_red3[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("找目标点三")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.7:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.6, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.6, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.7:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.10, 0.65, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.10, -0.65, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 3:
                        # calculate the difference between the target direction and the current direction
                        diff_rot,dx,dy = orientation(self.goal_red4[0],self.goal_red4[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("找目标点四")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.7:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.7:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.10, 0.65, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.10, -0.65, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 4:
                        # calculate the difference between the target direction and the current direction
                        diff_rot,dx,dy = orientation(self.goal_red5[0],self.goal_red5[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("寻物")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.8:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.8 :
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.05, 0.2, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.05, -0.2, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 5:
                        # diff_rot,dx,dy = orientation(self.goal_coffee_mug[0],self.goal_coffee_mug[1],pos[0],pos[1],rpy[2])
                        # distaction = math.sqrt(dx*dx+dy*dy)
                        # joint_efforts = self.ctrl_client_.get_cmd(
                        #     obs, 0.0, 0, 0, False
                        # )
                        print('取物品')
                        if not pick:
                            q_arm[7] = 1.8
                            q_arm[6] =1.8
                            q_arm[4] = -1.5
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.1, 0.1, 0, False
                            )
                        else:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, -2.0, 0.2, -0.3, 1
                            )
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, -2.0, 0.2, -0.3, 1
                            )
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, -2.0, 0.2, -0.3, 1
                            )
                            self.step+=1
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                            # "release":'False'
                        }
                        return action
                if self.step == 6:
                        diff_rot,dx,dy = orientation(self.goal_red4[0],self.goal_red4[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print(str_goal)
                        print("找目标点四")
                        # round the rotation difference, to avoid the agent to rotate more than 180 degrees
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        # if the agent is nearq_arm = agent["joint_state"]["arms_positions"]ly facing the goal, move forward
                        if abs(diff_rot) < np.pi / 90 and distaction<=0.7:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                            self.step+=1
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.8, 0, 0, False
                            )
                        elif abs(diff_rot) < np.pi / 90 and distaction>0.7:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.3, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.10, 0.65, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.10, -0.65, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand'
                        }

                        return action
                if self.step == 7:
                        diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                        distaction = math.sqrt(dx*dx+dy*dy)
                        print('前往目的地')
                        q_arm[7] = 1.8
                        q_arm[6] =1.8
                        q_arm[4] = -1.8
                        # joint_efforts = self.ctrl_client_.get_cmd(
                        #     obs, 0.3, 0, 0, False
                        # )
                        if abs(diff_rot) > np.pi:
                            diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

                        if abs(diff_rot) < np.pi / 90 and distaction<=3.0:
                            # call bipedal controller to get joint effort given a target velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.6, 0, 0, False
                            )
                            self.step+=1
                        elif abs(diff_rot) < np.pi / 90 and distaction>3.0:
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0.6, 0, 0, False
                            )
                        elif diff_rot > 0:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, 0.05, 0.2, False
                            )
                        else:
                            # call bipedal controller to get joint effort given a target angular velocity
                            joint_efforts = self.ctrl_client_.get_cmd(
                                obs, 0, -0.05, -0.2, False
                            )

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":[],
                                "dampings":[],
                            },
                            "pick":'right_hand',
                            "release":'False'
                        }

                        return action
                    
                if self.step == 8:
                        # diff_rot,dx,dy = orientation(self.goal_coffeetable[0],self.goal_coffeetable[1],pos[0],pos[1],rpy[2])
                        # distaction = math.sqrt(dx*dx+dy*dy)
                        print('放物品')
                        joint_efforts = self.ctrl_client_.get_cmd(
                            obs, 0.0, 0, 0, 0
                        )
                        q_arm[7] = -1.0

                        # wrap joint effort into tongverse-lite action format
                        action = {
                            "legs": {
                                "ctrl_mode": joint_efforts["mode"],
                                "joint_values": joint_efforts["effort"],
                                "stiffness": [],
                                "dampings": [],
                            },
                            "arms":{
                                "ctrl_mode":"position",
                                "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                                "stiffness":None,
                                "dampings":[],
                            },
                            #"pick":'right_hand',
                            "release":True
                        }

                        return action
