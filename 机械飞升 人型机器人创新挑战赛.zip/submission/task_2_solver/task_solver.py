import json
import numpy as np
import transforms3d as t3d
import math
from tongverselite.tcp import PersistentTcpClient, json2bin
from tongverselite.solver import TaskSolverBase


class BipedWalkingCtrlClient(PersistentTcpClient):
    def send_request(self, msg):
        data_bin = json2bin(msg)
        return json.loads(self.send(data_bin).decode("ascii"))

    def get_cmd(self, obs, vx, vy, theta, state):
        obs_agent = obs["agent"]
        q_leg = obs_agent["joint_state"]["legs_positions"]
        dq_leg = obs_agent["joint_state"]["legs_velocities"]

        q_arm = obs_agent["joint_state"]["arms_positions"]
        dq_arm = obs_agent["joint_state"]["arms_velocities"]

        p_wb = obs_agent["body_state"]["world_pos"]
        quat_wb = obs_agent["body_state"]["world_orient"]   #orient方向
        v_wb = obs_agent["body_state"]["linear_velocities"]
        w_wb = obs_agent["body_state"]["angular_velocities"]
        pick = obs["pick"]

        msg = {
            "q_leg": q_leg.tolist(),
            "dq_leg": dq_leg.tolist(),
            "q_arm": q_arm.tolist(),
            "dq_arm": dq_arm.tolist(),
            "p_wb": p_wb.tolist(),
            "quat_wb": quat_wb.tolist(),
            "v_wb": v_wb.tolist(),
            "w_wb": w_wb.tolist(),
            "command": [vx, vy, theta],  #指令
            "change_state": state,
            "pick":pick,
        }
        joint_efforts = self.send_request(msg)

        return joint_efforts

class TaskSolver(TaskSolverBase):
    def __init__(self) -> None:
        super().__init__()
        self.ctrl_client_ = BipedWalkingCtrlClient(ip="0.0.0.0", port=8800)
        self.goal_ = np.array([-0.00342, -9.43167, 0.59])#valve_47_link0.59
        self.radius = 0.5  # 圆弧半径
        self.step = 0
    

    def next_action(self, obs: dict) -> dict:
        agent = obs["agent"]
        pos = agent["body_state"]["world_pos"]
        quat = agent["body_state"]["world_orient"]   #四元数
        q_arm = agent["joint_state"]["arms_positions"]
        dq_arm = agent["joint_state"]["arms_velocities"]
        
        rpy = t3d.euler.quat2euler(quat, axes="sxyz")
        dx = self.goal_[0] - pos[0]
        dy = self.goal_[1] - pos[1]
        target_dir = np.arctan2(dy, dx)
        diff_rot = target_dir - rpy[2]
        pick = obs["pick"]
        distaction = math.sqrt(dx*dx+dy*dy)
        if self.step == 0:
            if abs(diff_rot) > np.pi:
                diff_rot += 2 * np.pi if diff_rot < 0 else -2 * np.pi

            # if the agent is nearly facing the goal, move forward 向前移动
            if abs(diff_rot) < np.pi / 90:
                # call bipedal controller to get joint effort given a target velocity 给定目标速度，调用双足控制器获得联合努力
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.3, 0, 0, False
                )
                if distaction <= 0.7:
                    self.step+=1
                    joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0.01, 0, 0, False
                )
                    
            elif diff_rot > 0:
                # call bipedal controller to get joint effort given a target angular velocity
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0, 0, 0.2, False
                )
            else:
                # call bipedal controller to get joint effort given a target angular velocity
                joint_efforts = self.ctrl_client_.get_cmd(
                    obs, 0, 0, -0.2, False
                )
            
            action = {
                "legs": {
                    "ctrl_mode": joint_efforts["mode"],
                    "joint_values": joint_efforts["effort"],
                    "stiffness": [],
                    "dampings": [],
                },
                "arms":{
                    "ctrl_mode":"position",
                    "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                    "stiffness":None,
                    "dampings":[],
                },
                "pick": "left_hand",
            
            }

            return action

            
        if self.step == 1:
            print("开始拧动阀门")
            q_arm[3] = -1.9
            joint_efforts = self.ctrl_client_.get_cmd(
            obs, -0.2 * np.cos(target_dir), 0.2 * np.sin(target_dir), -0.2, False
            )
            action = {
                "legs": {
                    "ctrl_mode": joint_efforts["mode"],
                    "joint_values": joint_efforts["effort"],
                    "stiffness": [],
                    "dampings": [],
                },
                "arms":{
                    "ctrl_mode":"position",
                    "joint_values": q_arm ,#obs["agent"]["joint_state"]["arms_positions"],#np.array([-0.250686,-0.0842871,-0.0842871,0.964143,1.21334,-9.59099,0.606334]),
                    "stiffness":[],
                    "dampings":[],
                },
                "pick": "left_hand",
            
            }

            return action
            

